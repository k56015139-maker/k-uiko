# KAI // CYBER LAB

A multi-page, browser-based cybersecurity learning lab for GitHub Pages.

## Included
- Security dashboard with local activity log
- Interactive terminal with safe built-in commands
- SHA-256 hash generator and text encoder/decoder
- Password-strength estimator that runs locally
- URL safety checklist (heuristics only; not a malware scanner)
- HTTP security-header checker (limited by browser CORS)
- Network topology simulator and sample packet viewer
- Capture-the-Flag puzzles
- Local admin settings and progress reset

## Publish on GitHub Pages
1. Create a public repository named `kai-cyber-lab`.
2. Upload the contents of this folder (not the ZIP itself).
3. Open **Settings → Pages**.
4. Choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then Save.
5. Wait for the Pages URL to appear.

## Important limits
This is a client-side static site. It cannot run privileged network scans, inspect visitors' devices, access accounts, or perform server-side actions. The URL checker uses simple indicators and is not a verdict. The header checker may be blocked by cross-origin restrictions. Only test systems you own or have permission to assess.

All user-entered text for hashing, encoding, and password analysis is processed in the browser. Avoid entering real passwords; use test strings.
